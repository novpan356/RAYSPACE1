from pathlib import Path
import json
import numpy as np
from scipy.signal import lfilter
import soundfile as sf
root=Path(__file__).resolve().parents[1];data=json.loads((root/'timeline.json').read_text());SR=48000;N=int(data['duration']*SR);music=np.zeros((N,2));foley=np.zeros((N,2));rng=np.random.default_rng(81203)
def put(dst,w,t,amp=1,pan=0):
 a=round(t*SR);b=min(N,a+len(w));
 if a<0 or b<=a:return
 gains=np.sqrt([(1-pan)/2,(1+pan)/2]);dst[a:b]+=np.asarray(w[:b-a])[:,None]*gains*amp

def tone(note,dur,kind='pulse',duty=.25):
 n=max(1,int(dur*SR));t=np.arange(n)/SR;hz=440*2**((note-69)/12);ph=t*hz
 if kind=='tri':w=2*np.abs(2*(ph%1)-1)-1;w=np.round((w+1)*7.5)/7.5-1
 else:w=np.where(ph%1<duty,1.,-1.)
 env=np.minimum(t/.004,1)*np.minimum(np.maximum(dur-t,0)/.035,1)*np.exp(-t*(2 if kind=='tri' else 3));return w*env
# An original eight-note motif, rearranged against 120 BPM. No external recordings.
melody=[69,72,76,74,71,67,69,64];bass=[45,41,43,40]
for beat in np.arange(0,48,.5):
 section=next(s['id'] for s in data['sections'] if s['start']<=beat<s['end']);i=round(beat*2);bar=int(beat//2)
 thin=section in ['mash','miss','loop'];rootnote=bass[(bar//2)%4]
 if i%2==0:put(music,tone(rootnote,.32,'tri'),beat,.105 if not thin else .075,0)
 if section!='loop' and (not thin or i%2==0):put(music,tone(melody[i%8]+(12 if section=='save' else 0),.24,'pulse',.125 if thin else .25),beat,.036 if thin else .047,-.22)
 if section in ['hook','guard','punish','retry','save']:
  put(music,tone(melody[(i+3)%8]-12,.18,'pulse',.5),beat+.25,.021,.35)
 # Short deterministic noise percussion and a triangle kick.
 if section not in ['loop','upgrade']:
  tt=np.arange(int(.035*SR))/SR;noise=rng.choice([-1.,1.],len(tt))*np.exp(-tt*110)
  put(music,noise,beat,.025 if i%2 else .016,.15)
  if i%4==0:put(music,tone(33,.11,'tri'),beat,.1)
# Stereo console-style echoes with a low-pass feedback colour.
dry=music.copy()
for delay,gain in [(.18,.22),(.27,.13),(.37,.08)]:
 shift=int(delay*SR);echo=lfilter([.25],[1,-.75],dry,axis=0);music[shift:]+=echo[:-shift,::-1]*gain
for e in data['hits']:
 t=e['t'];k=e['type']
 if k in ['hit','ko']:
  d=.24 if k=='hit' else .48;tt=np.arange(int(d*SR))/SR;noise=rng.choice([-1.,1.],len(tt));thump=np.sin(2*np.pi*(80*tt-35*tt*tt));w=(lfilter([.2],[1,-.8],noise)*.7+thump*.8)*np.exp(-tt*18);put(foley,w,t,.32 if k=='hit' else .4,-.05)
 elif k=='guard':
  tt=np.arange(int(.2*SR))/SR;w=(np.sin(2*np.pi*1300*tt)+.4*np.sin(2*np.pi*1900*tt))*np.exp(-tt*38);put(foley,w,t,.13,.2)
 elif k=='swish':
  tt=np.arange(int(.15*SR))/SR;put(foley,rng.choice([-1.,1.],len(tt))*np.sin(np.pi*tt/.15)**2,t,.055,-.2)
 elif k in ['confirm','save']:
  for n,note in enumerate([76,81,88]):put(foley,tone(note,.12,'tri'),t+n*.065,.1,.15)
 elif k=='miss':
  put(foley,tone(49,.25,'pulse',.125),t,.055,0)
 else:put(foley,tone(83 if k=='transfer' else 79,.06),t,.065,-.15)
# Every dialogue entry gets distinct quiet text blips; walking gets restrained footfalls.
for s in data['sections']:
 for i in range(0,len(s['sub']),2):put(foley,tone(82+(i%3),.018),s['start']+.15+i/38,.018,-.3)
for t in np.arange(28,34,.35):
 tt=np.arange(int(.045*SR))/SR;put(foley,rng.choice([-1.,1.],len(tt))*np.exp(-tt*90),t,.045,0)
# Two genuine silent rests, including tails. Tiny edge ramps avoid artificial clicks.
mix=music+foley
for a,b in data['silences']:
 lo=int(a*SR);hi=int(b*SR);edge=int(.02*SR)
 mix[max(0,lo-edge):lo]*=np.linspace(1,0,min(edge,lo))[:,None]
 mix[lo:hi]=0
 mix[hi:min(N,hi+edge)]*=np.linspace(0,1,min(edge,N-hi))[:,None]
end=int(.12*SR);mix[-end:]*=np.linspace(1,0,end)[:,None]
mag=np.abs(mix);mix=np.sign(mix)*np.where(mag<=.08,mag,.08+(mag-.08)/4)
peak=np.abs(mix).max();assert peak>0;mix*=.82/max(1,peak)
(root/'audio').mkdir(exist_ok=True);sf.write(root/'audio/mix.wav',mix,SR,subtype='PCM_24');sf.write(root/'audio/music.wav',music,SR,subtype='PCM_24');sf.write(root/'audio/foley.wav',foley,SR,subtype='PCM_24')
print('Original chiptune + action foley:',len(mix)/SR,'s, peak',float(np.abs(mix).max()))
