from pathlib import Path
import json,re,subprocess
import numpy as np
import soundfile as sf
root=Path(__file__).resolve().parents[1];data=json.loads((root/'timeline.json').read_text());reports=[]
def stamp(t):
 ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
subs=[]
for i,s in enumerate(data['sections'],1):
 assert s['end']>s['start'];txt=s['sub'];cn=len(re.findall(r'[\u4e00-\u9fff]',txt));other=len(txt)-cn;needed=cn/4.5+other/15+1.5;fully_visible=s['end']-s['start']-.15-len(txt)/38
 assert fully_visible>=needed,(s['id'],fully_visible,needed)
 subs.append(f'{i}\n{stamp(s["start"])} --> {stamp(s["end"])}\n{txt}\n')
 reports.append({'id':s['id'],'fullTextHold':round(fully_visible,3),'requiredHold':round(needed,3)})
(root/'tekken8-pixel-lesson.srt').write_text('\n'.join(subs))
for s in data['sections']:assert abs(s['start']/2-round(s['start']/2))<1e-6,'cut off bar grid'
for e in data['hits']:assert 0<=e['t']<48 and abs(e['t']/.125-round(e['t']/.125))<1e-6,'cue off sixteenth grid'
if (root/'audio/mix.wav').exists():
 audio,sr=sf.read(root/'audio/mix.wav');assert len(audio)==48*sr;assert np.abs(audio).max()<1
 for a,b in data['silences']:assert np.abs(audio[int(a*sr):int(b*sr)]).max()==0
if (root/'tekken8-pixel-lesson.mp4').exists():
 r=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(root/'tekken8-pixel-lesson.mp4')]))
 v=next(x for x in r['streams'] if x['codec_type']=='video');assert (v['width'],v['height'])==(1920,1080);assert v['r_frame_rate']=='24/1';assert int(v['nb_frames'])==1152
 assert any(x['codec_type']=='audio' for x in r['streams']);assert abs(float(r['format']['duration'])-48)<.05
(root/'out/checks.json').write_text(json.dumps({'subtitles':reports,'cueGrid':'passed','silenceChecks':'passed'},ensure_ascii=False,indent=2))
print('Checks passed: subtitle holds, 9 cues, beat grid, 2 true silences'+(', 1152 frames with audio' if (root/'tekken8-pixel-lesson.mp4').exists() else ''))
