#!/bin/sh
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
LIB=${LEMO_OPUSCAR_HOME:-/home/agent/lemo-opuscar}
[ -f "$LIB/core/render/video.mjs" ] || { echo 'Set LEMO_OPUSCAR_HOME to the installed library path'; exit 1; }
[ ! -f "$LIB/.lemo-runtime-env.sh" ] || . "$LIB/.lemo-runtime-env.sh"
PY="$LIB/.venv/bin/python"
mkdir -p "$HERE/out" "$HERE/audio"
"$PY" "$HERE/tools/glyphs.py"
"$PY" "$HERE/tools/audio.py"
"$PY" "$HERE/tools/checks.py"
ffmpeg -y -hide_banner -loglevel error -i "$HERE/audio/mix.wav" -af "acompressor=threshold=0.04:ratio=6:attack=1:release=60:makeup=1" -c:a pcm_s24le "$HERE/audio/master.wav"
cd "$LIB"
node core/render/readcheck.mjs "$HERE" --step 0.1
node core/render/events.mjs "$HERE" > "$HERE/out/events.log"
node core/render/video.mjs "$HERE" --fps 24 --workers 3 --out "$HERE/out/video.mp4" --size 1920x1080
sh core/render/mux.sh "$HERE/out/video.mp4" "$HERE/audio/master.wav" "$HERE/tekken8-pixel-lesson.mp4" 24 0
ffmpeg -y -hide_banner -loglevel error -ss 0.8 -i "$HERE/tekken8-pixel-lesson.mp4" -frames:v 1 -q:v 2 "$HERE/poster.jpg"
"$PY" "$HERE/tools/checks.py"
