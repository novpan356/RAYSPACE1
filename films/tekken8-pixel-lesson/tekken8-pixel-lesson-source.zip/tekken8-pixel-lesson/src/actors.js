import {FB,T,outline,capsule} from './pixel.js';
const poses={idle:{hip:[0,-13],shoulder:[0,-23],head:[0,-31],feet:[[-4,0],[5,0]],arms:[[[1,-22],[6,-21],[8,-26]],[[-2,-22],[-5,-18],[-1,-17]]]},punch:{hip:[2,-13],shoulder:[4,-23],head:[4,-31],feet:[[-5,0],[8,0]],arms:[[[5,-22],[12,-22],[19,-22]],[[1,-22],[0,-18],[6,-18]]]},wind:{hip:[-1,-13],shoulder:[-2,-23],head:[-2,-31],feet:[[-5,0],[5,0]],arms:[[[-2,-22],[-10,-23],[-11,-29]],[[-4,-22],[-1,-17],[5,-17]]]},guard:{hip:[-1,-13],shoulder:[-2,-23],head:[-2,-31],feet:[[-5,0],[4,0]],arms:[[[-1,-22],[5,-24],[6,-31]],[[-4,-22],[1,-20],[5,-26]]]},hurt:{hip:[-3,-12],shoulder:[-6,-22],head:[-8,-30],feet:[[-6,0],[3,0]],arms:[[[-4,-21],[-8,-16],[-2,-15]],[[-8,-21],[-10,-17],[-5,-15]]]},recover:{hip:[3,-13],shoulder:[6,-22],head:[9,-29],feet:[[-4,0],[7,0]],arms:[[[7,-21],[12,-15],[15,-15]],[[3,-21],[4,-16],[8,-15]]]},win:{hip:[0,-13],shoulder:[0,-23],head:[0,-31],feet:[[-4,0],[5,0]],arms:[[[1,-22],[7,-29],[7,-37]],[[-3,-22],[-7,-17],[-3,-16]]]},down:{hip:[5,-4],shoulder:[-5,-4],head:[-14,-4],feet:[[16,-1],[19,-4]],arms:[[[-4,-4],[-2,-1],[5,-1]],[[-7,-4],[-8,-1],[-3,-1]]]}};
function blended(a,b,t){if(Array.isArray(a))return a.map((v,i)=>blended(v,b[i],t));if(typeof a==='number')return a+(b-a)*t;return Object.fromEntries(Object.keys(a).map(k=>[k,blended(a[k],b[k],t)]))}
export function poseMix(a,b,t){return blended(poses[a],poses[b],Math.max(0,Math.min(1,t)))}
export function actor(kind='hero',pose='idle',t=0,walk=false,view='side'){
 const f=new FB(56,54),p=typeof pose==='string'?structuredClone(poses[pose]):structuredClone(pose),ox=25,oy=48;
 if(walk){const steps=[[-6,3],[-2,1],[4,-5],[1,-2]][Math.floor(Math.max(0,t)*8)%4];p.feet=[[steps[0],0],[steps[1],-1]];p.shoulder[1]-=Math.floor(t*8)%2;p.head[1]-=Math.floor(t*8)%2;}
 const body=kind==='hero'?[10,11,12]:[23,24,25],pants=[1,2,3],skin=kind==='hero'?[16,17,13]:[4,5,6];
 const pos=a=>[ox+a[0],oy+a[1]],limb=(a,b,r,c)=>capsule(f,...pos(a),...pos(b),r,c);
 limb([p.hip[0]-2,p.hip[1]],p.feet[0],2,pants);limb([p.hip[0]+2,p.hip[1]],p.feet[1],2,pants);
 for(const foot of p.feet)f.rect(ox+foot[0]-2,oy+foot[1]-1,6,2,0);
 limb(...p.arms[1].slice(0,2),2,body);limb(...p.arms[1].slice(1),1.6,skin);
 limb(p.hip,p.shoulder,4,body);f.rect(ox+p.hip[0]-4,oy+p.hip[1]-2,8,3,kind==='hero'?26:20);
 limb(...p.arms[0].slice(0,2),2,body);limb(...p.arms[0].slice(1),1.8,skin);
 const [hx,hy]=pos(p.head);f.rect(hx-3,hy-3,7,8,skin[1]);f.rect(hx-2,hy-2,6,6,skin[2]);
 if(kind==='hero'){f.rect(hx-4,hy-6,8,4,15);f.rect(hx-3,hy-7,3,2,16);f.rect(hx+1,hy-7,2,2,15);f.rect(hx-4,hy-3,2,5,15);f.px(hx-1,hy-5,17);if(view!=='back'){f.px(hx+2,hy,31);f.px(hx+3,hy,0);f.line(hx+1,hy+3,hx+3,hy+3,16);}f.rect(ox+p.shoulder[0]-4,oy+p.shoulder[1]-1,2,6,27);}else{f.rect(hx-4,hy-5,8,3,20);f.rect(hx-4,hy-3,2,7,4);if(view!=='back'){f.rect(hx+1,hy-1,3,2,25);f.px(hx+3,hy-1,31);f.line(hx+1,hy+3,hx+3,hy+3,3);}}
 if(view==='front'){f.px(hx-1,hy,0);f.px(hx+2,hy,0);}return outline(f);
}
export function portrait(mood='worried'){
 const f=new FB(32,32);f.grad(0,0,32,32,[2,1]);f.rect(4,25,26,7,10);f.rect(8,25,19,7,11);f.rect(11,23,10,5,17);f.rect(7,5,19,21,16);f.rect(9,7,15,18,13);f.rect(6,1,20,8,15);f.rect(9,0,7,5,16);f.rect(19,2,6,6,15);f.rect(6,7,3,12,15);f.rect(25,8,2,11,15);f.rect(10,12,5,3,31);f.rect(19,12,5,3,31);f.rect(13,12,2,3,0);f.rect(20,12,2,3,0);f.px(17,19,17);
 if(mood==='angry'){f.line(10,9,15,11,15);f.line(19,11,24,9,15);f.line(13,23,20,23,16);}else if(mood==='happy'){f.line(10,10,15,10,15);f.line(19,10,24,10,15);f.line(12,21,14,23,16);f.line(14,23,20,23,16);f.line(20,23,22,21,16);}else if(mood==='resolve'){f.line(10,10,15,11,15);f.line(19,11,24,10,15);f.line(13,22,21,22,16);}else{f.line(10,10,15,8,15);f.line(19,8,24,10,15);f.line(13,24,16,22,16);f.line(16,22,21,24,16);}return f;
}
