import {FB,W,H,T,ease,clamp,mix,windowBox,bayer,present} from './pixel.js';
import {actor,portrait,poseMix} from './actors.js';
const timeline=await fetch('./timeline.json').then(r=>r.json());const glyphs=await fetch('./fonts/glyphs.json').then(r=>r.json());
const canvas=document.querySelector('canvas');canvas.width=innerWidth;canvas.height=innerHeight;
const fb=new FB();let boxes=[];
function glyph(ch){return glyphs[ch]||glyphs['?']}
function textW(s,scale=1){return [...s].reduce((w,ch)=>w+(glyph(ch).w+1)*scale,0)-scale}
function text(s,x,y,col=31,scale=1,align='left',shadow=true,id=null){if(align==='center')x-=Math.floor(textW(s,scale)/2);if(align==='right')x-=textW(s,scale);const origin=x;const draw=(dx,dy,c)=>{let xx=x;for(const ch of s){const g=glyph(ch);for(let j=0;j<g.h;j++)for(let i=0;i<g.w;i++)if(g.rows[j]&(1<<(g.w-1-i)))fb.rect(xx+i*scale+dx,y+j*scale+dy,scale,scale,c);xx+=(g.w+1)*scale}};if(shadow)draw(scale,scale,0);draw(0,0,col);if(id)boxes.push({id,text:s,x0:origin*innerWidth/W,y0:y*innerHeight/H,x1:(origin+textW(s,scale)+1)*innerWidth/W,y1:(y+14*scale)*innerHeight/H});}
function banner(label,id){windowBox(fb,20,3,280,23);text(label,160,7,31,1,'center',true,id)}
function character(x,ground,kind,pose,t,scale=2,face=1,walk=false,view='side'){const s=actor(kind,pose,Math.floor(t*12)/12,walk,view);fb.blit(s,Math.round(x-(face<0?30:25)*scale),Math.round(ground-48*scale),scale,face<0)}
function arena(t,cam=0,bright=false){fb.grad(0,0,320,100,bright?[2,3,4]:[1,2,3]);for(let i=-2;i<15;i++){const x=i*29-Math.round(cam*.25),h=18+(i*i%5)*7;fb.rect(x,90-h,24,h,2);fb.rect(x+2,92-h,20,h-4,3);for(let y=95-h;y<85;y+=8)for(let xx=x+4;xx<x+20;xx+=7)fb.rect(xx,y,2,2,(i+xx+y)%4===0?13:4)}fb.rect(0,88,320,9,1);fb.rect(0,90,320,2,5);for(let i=-2;i<12;i++){const x=i*43-Math.round(cam*.6);fb.rect(x,41,5,53,1);fb.rect(x+1,42,2,51,3);fb.rect(x+8,45,18,29,i%2?26:8);fb.rect(x+9,47,14,23,i%2?27:9);fb.line(x+13,50,x+21,60,6);fb.line(x+21,50,x+13,60,6);fb.rect(x+12,73,9,2,0);}fb.grad(0,97,320,37,[3,2,1]);for(let y=99;y<134;y+=7){fb.line(0,y,319,y,4);for(let x=-80;x<400;x+=38)fb.line(x-Math.round(cam)+(y%2)*10,y,x+13-Math.round(cam),Math.min(133,y+7),2)}fb.rect(0,129,320,5,0);fb.line(0,128,319,128,5);}
function hp(left=1,right=1){text('P1',14,30,13);text('BOT',287,30,22);fb.rect(34,30,88,6,0);fb.rect(35,31,86,4,8);fb.rect(35,31,Math.round(86*left),2,28);fb.rect(35,33,Math.round(86*left),2,27);fb.rect(198,30,77,6,0);fb.rect(199,31,75,4,8);fb.rect(199,31,Math.round(75*right),2,25);fb.rect(199,33,Math.round(75*right),2,24)}
function spark(x,y,t,color=13){const k=Math.floor(t*24);if(k<0||k>8)return;const r=3+(8-k);for(let i=0;i<8;i++){const a=i*Math.PI/4;fb.line(x+Math.cos(a)*2,y+Math.sin(a)*2,x+Math.cos(a)*r,y+Math.sin(a)*r,color)}fb.disc(x,y,Math.max(0,4-Math.floor(k/2)),31)}
function shield(x,y,t){const n=Math.floor(t*12);if(n<0||n>5)return;fb.line(x,y-9,x+4,y-5,30);fb.line(x+4,y-5,x+4,y+5,30);fb.line(x+4,y+5,x,y+9,30);fb.line(x+2,y-9,x+6,y-5,6);fb.line(x+6,y-5,x+6,y+5,6)}
function arrow(x,y,col=13){for(let i=0;i<5;i++)fb.line(x+i,y-i,x+i,y+i,col)}
function label(s,x,y,color=13,id=null){const w=textW(s)+8;fb.rect(x-w/2-1,y-2,w+2,18,0);fb.rect(x-w/2,y-1,w,16,1);text(s,x,y,color,1,'center',true,id)}
function dialog(s,local,mood){windowBox(fb,6,134,308,43);fb.rect(11,138,35,35,0);fb.blit(portrait(mood),13,140);text(mood==='happy'?'QUEST / SAVED':mood==='resolve'?'TRAINING / P1':'ROOKIE / P1',51,141,6,1,'left',false);const count=Math.max(0,Math.floor((local-.15)*38));text([...s].slice(0,count).join(''),51,154,31,1,'left',true);if(count>=s.length&&Math.floor(local*3)%2===0){for(let i=0;i<4;i++)fb.line(301+i,169,307-i,169+i,31)}}
function mash(u,t){const impact=u>=2&&u<4?2:u>=4?4:null;const age=impact===null?-1:u-impact;const attack=((u%2)>=1.5&&(u%2)<2);let hpHero=u<2?1:u<4?.56:.18;const px=124+(age>=0&&age<.5?-Math.round(Math.sin(age*Math.PI*2)*13):0);character(px,127,'hero',age>=0&&age<.8?'hurt':attack?'punch':'idle',t);character(194-(attack||age>=0&&age<.35?18:0),127,'bot',attack?'punch':age>=0&&age<.8?'recover':'idle',t,2,-1);hp(hpHero,1);label('对手回合',202,43,12,'mash-turn');if(u>=2){text('COUNTER',122,62,12,1,'center',true,'mash-counter');}if(age>=0)spark(143,82,age);if(u<1.4){text('A A A A',112,112,13,1,'center');arrow(88,115,13)}}
function miss(u,t){const hit=u-1;character(124,127,'hero',u>=.8&&u<1.6?'guard':'idle',t);character(194-(u>=.7&&u<1.25?18:0),127,'bot',u<.7?'wind':u<1.1?'punch':u<3.75?'recover':'idle',t,2,-1);hp(.8,1);shield(141,82,hit);if(u>=1.5&&u<3.75){label('破绽',198,48,12);fb.rect(168,67,53,4,0);fb.rect(169,68,Math.round(51*(3.75-u)/2.25),2,12);text('?',127,65,13,2,'center')}if(u>=3.75)label('错过了',160,54,11,'miss-late')}
function menuLoop(u,t){character(250,127,'hero',u>2?'down':'idle',t,1);windowBox(fb,22,41,198,81);text('NEXT MATCH?',42,48,13);text('再排一把',48,68,31,1,'left',true,'retry-menu');text('看次回放',48,94,5,1,'left',true,'replay-menu');arrow(32,75,12);if(u>2){fb.rect(230,98,67,20,8);text('KO',264,104,12,2,'center');text('AGAIN',264,120,6,1,'center');}for(let i=0;i<3;i++)fb.rect(32+i*10,115,7,3,i<Math.floor(u/2)?11:3)}
function upgrade(u,t){windowBox(fb,16,32,214,96);text('PRACTICE POINTS',32,40,13);text('连招',39,61,7,1,'left',true,'up-combo');text('判断',39,89,30,1,'left',true,'up-think');fb.rect(108,64,100,9,0);fb.rect(109,65,u<3?90:62,7,11);fb.rect(108,92,100,9,0);fb.rect(109,93,u<3?13:66,7,30);text(u<3?'99':'98',194,78,13);text(u<3?'01':'02',194,106,30);arrow(25,u<2?67:95,u<2?13:30);const f=ease((u-2)/1);if(u>=2&&u<=3){fb.disc(Math.round(mix(203,113,f)),Math.round(mix(69,97,f)),3,30)}character(271,127,'hero',u>3?poseMix('idle','win',ease((u-3)/.3)):'idle',t,2);if(u>=3)text('LEARNED!',268,45,30,1,'center',true,'learned')}
function dojo(u,t){fb.grad(0,0,320,134,[1,2,3]);for(let y=32;y<130;y+=16)for(let x=0;x<320;x+=16){fb.rect(x,y,15,15,(x/16+y/16)%2?2:3);fb.rect(x+2,y+2,11,1,4)}const pan=Math.round(ease(u/6)*26);for(let i=0;i<4;i++){const x=37+i*76-pan;windowBox(fb,x,41,58,42);text(['防','守','等','打'][i],x+29,53,i<3?30:13,1,'center');fb.rect(x+15,86,29,5,i<3?27:18);}const px=Math.round(mix(56,250,ease(u/6)));character(px,124,'hero','guard',t,1,1,true,'front');if(u>=1&&u<1.7)shield(px+13,107,u-1);if(u>=2.5&&u<3.2)shield(px+13,107,u-2.5);if(u>=4&&u<4.7)shield(px+13,107,u-4);text('WAIT > ACT',160,33,6,1,'center',true,'guard-note')}
function practice(u,t,final=false){const blockAt=final?.75:1.5,hitAt=final?2:2;const cycle=final?u:u%2;const phase=final?u:cycle;let hero='idle',bot='idle',hx=124,bx=194;if(final){if(u<.45)bot='wind';else if(u<.85){bot='punch';bx=176;hero='guard'}else if(u<1.65){hero='guard';bot='recover'}else if(u<2.15){hero='punch';hx=142;bot=u>=2?'hurt':'recover'}else if(u<2.9)bot='hurt';else hero='idle'}else{if(cycle<1.25)bot='wind';else if(cycle<1.6){bot='punch';bx=176;hero='guard'}else{bot='recover';hero='punch';hx=142}if(u>=2&&cycle<.4)bot='hurt';}
 if(final){
  if(u<.45)bot=poseMix('idle','wind',ease(u/.3));
  else if(u<.85){bot=poseMix('wind','punch',ease((u-.45)/.18));hero=poseMix('idle','guard',ease((u-.45)/.15));}
  else if(u<1.65)bot=poseMix('punch','recover',ease((u-.85)/.2));
  if(u>=1.65&&u<2.15)hero=poseMix('guard','punch',ease((u-1.65)/.25));
  if(u>=2.15&&u<2.55)hero=poseMix('punch','idle',ease((u-2.15)/.4));
  if(u>=2&&u<2.3)bot=poseMix('recover','hurt',ease((u-2)/.15));
  if(u>=2.7&&u<3.2)bot=poseMix('hurt','idle',ease((u-2.7)/.5));
 }
 character(hx,127,'hero',hero,t);character(bx,127,'bot',bot,t,2,-1);hp(final?.65:1,final?(u>=2?.78:1):Math.max(.55,1-Math.floor(u/2)*.17));if(final){shield(141,82,u-.75);spark(177,80,u-2,30);if(u>=2)text('PUNISH!',174,56,30,1,'center',true,'final-punish');}else{const local=u>=4?u-4:u>=2?u-2:u;shield(141,82,local-1.5);if(u>=2)spark(177,80,local,30);text('BLOCK > PUNISH',160,45,30,1,'center',true,'practice-command');for(let i=0;i<3;i++){fb.rect(143+i*13,64,9,4,3);if(u>=2+i*2)fb.rect(144+i*13,65,7,2,30)}}}
function save(u,t){arena(t,0,true);windowBox(fb,18,10,212,59);text('先少挨打',124,17,31,2,'center',true,'end-a');text('再打更痛',124,48,13,1,'center',true,'end-b');windowBox(fb,18,76,205,52);text('TODAY\'S QUEST',30,83,30);text('只改一个错',38,103,31,1,'left',true,'end-task');text('SAVED',188,86,30,1,'right');character(272,127,'hero',poseMix('idle','win',ease(u/.35)),t,2);for(let i=0;i<3;i++){fb.rect(228+i*7,119-i*5,4,4,30)}}
function sheet(){fb.clear(1);text('ORIGINAL / ROOKIE',160,6,31,1,'center');const names=['idle','guard','wind','punch','hurt','win'];names.forEach((p,i)=>{character(29+i*52,72,'hero',p,i,1,i===4?-1:1);text(p.toUpperCase(),29+i*52,79,6,1,'center')});['worried','angry','resolve','happy'].forEach((m,i)=>{fb.blit(portrait(m),25+i*75,101);text(m.toUpperCase(),41+i*75,138,31,1,'center')});for(let i=0;i<32;i++)fb.rect(i*10,162,10,12,i);text('32 INDEXED COLOURS / 320 X 180',160,150,6,1,'center')}
function sectionAt(t){return timeline.sections.find(s=>t>=s.start&&t<s.end)||timeline.sections.at(-1)}
window.DUR=timeline.duration;window.SUBS=timeline.sections.map(s=>({a:s.start,b:s.end,text:s.sub}));window.EV=timeline.hits;
window.render=t=>{t=clamp(t,0,47.999);boxes=[];fb.clear(0);if(new URLSearchParams(location.search).has('sheet')){sheet();present(fb,canvas);return}const s=sectionAt(t),u=t-s.start;arena(t,Math.round(Math.sin(t*.3)*6));let mode='full',flood=1;
 if(s.id==='hook'){character(127-(u>2.5?10:0),127,'hero',u<2?'punch':u<2.5?'hurt':'down',t,1);character(193,127,'bot',u<2?'idle':'punch',t,1,-1);windowBox(fb,28,4,264,65);text('你为什么打不好',160,11,31,1,'center',true,'opening-a');text('铁拳8',160,34,13,2,'center',true,'opening-b');text('COMBO 99',93,78,30);text(u<2.5?'VS':'KO',160,86,u<2.5?6:12,2,'center');if(u>2.5)mode='faded'}
 else{if(s.id==='mash')mash(u,t);if(s.id==='miss')miss(u,t);if(s.id==='loop'){menuLoop(u,t);mode='faded'}if(s.id==='upgrade'){upgrade(u,t);mode='flood';flood=ease((u-2.8)/1.2)}if(s.id==='guard')dojo(u,t);if(s.id==='punish')practice(u,t);if(s.id==='retry')practice(u,t,true);if(s.id==='save')save(u,t)}
 if(!['hook','save'].includes(s.id))banner(s.label,'chapter-'+s.id);
 const mood=s.id==='save'?'happy':['upgrade','guard','punish','retry'].includes(s.id)?'resolve':s.id==='mash'?'angry':'worried';dialog(s.sub,u,mood);
 // A few pixels of a bounded encounter shake. UI remains stable and readable.
 if(['mash','miss','punish','retry'].includes(s.id)){
  let z=1,cx=160,cy=94;
  if(s.id==='hook')z=1+.08*ease(u/4);
  if(s.id==='mash')cx+=Math.round(6*ease(u/6));
  if(s.id==='miss')z=1.12-.12*ease(u/6);
  if(s.id==='guard')cx+=Math.round(12*ease(u/6));
  if(s.id==='punish')z=1+.1*ease(u/6);
  if(s.id==='retry')cx+=Math.round(4*ease((u-2)/2));
  const copy=new Uint8Array(fb.d);
  for(let yy=42;yy<134;yy++)for(let xx=0;xx<320;xx++){
   const sx=Math.max(0,Math.min(319,Math.round((xx-160)/z+cx))),sy=Math.max(0,Math.min(133,Math.round((yy-94)/z+cy)));
   fb.d[yy*320+xx]=copy[sy*320+sx];
  }
 }
 const near=Math.min(u,s.end-t),block=near<.22?Math.max(1,Math.round(1+(1-near/.22)*7)):1;
 if(block>1&&!['hook','save'].includes(s.id))for(let yy=27;yy<134;yy+=block)for(let xx=0;xx<320;xx+=block)fb.rect(xx,yy,Math.min(block,320-xx),Math.min(block,134-yy),fb.get(xx,yy));
 present(fb,canvas,mode,flood);window.FRAME={section:s.id,indices:[...new Set(fb.d)],textBoxes:boxes};};
window.TEXTS=t=>{window.render(t);return boxes};window.render(0);window.READY=true;
